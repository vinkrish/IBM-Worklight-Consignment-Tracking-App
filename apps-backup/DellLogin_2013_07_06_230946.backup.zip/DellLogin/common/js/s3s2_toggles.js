function toggles()
{
var s = document.getElementById('s');
var sp = document.getElementById('sp');
if(sp.style.opacity == '0')
{
	sp.style.opacity = '1';
	//common_s7s1();
}
common_s7s1();
//setTimeout(common_s7s1(),1000);
//setTimeout(int_common_s7s1(),1000);
}
