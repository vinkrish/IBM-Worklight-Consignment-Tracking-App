
/* JavaScript content from js/DellLogin.js in folder common */

// Worklight comes with the jQuery framework bundled inside. If you do not want to use it, please comment out the line below.
window.$ = window.jQuery = WLJQ;

var Current_barcode = null;

function wlCommonInit(){
	// Common initialization code goes here
	
	busyIndicator = new WL.BusyIndicator('AppBody');
	WL.Page.load("pages/DellLogin.html", {
		onComplete: function() { WL.Logger.debug("DellLogin.html load"); },
		onUnload: function() { WL.Logger.debug("DellLogin.html load");  } 
	});	
}

var busyIndicator = null;


function doLogin() {
	var user = $('username').getValue();
	var pswd = $('password').getValue();
	if (user == null || user == "") {
		alert("Please enter user name");
		return;
	} else if (pswd == null || pswd == "") {
		alert("Please enter password");
		return;
	} else {
		doAuthenticate_LDAP();
	}
}

function doAuthenticate_LDAP() {
	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();

	var userN = document.getElementById('username').value;
	var pwd = document.getElementById('password').value;

	var invocationData = {
		adapter : 'LDAPAdapter',
		procedure : 'doAuthenticateLDAP',
		parameters : [ userN, pwd ]
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : authLDAP_loadFeedsSuccess,
		onFailure : authLDAP_loadFeedsFailure,
	});
}
function authLDAP_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result actual: " + JSON.stringify(result));
	if(result.invocationResult.ApplicationGroups == undefined)
	{
		alert('Invalid User');
	}else{
		WL.Page.load("s3s2.html", {
			onComplete : function() {
				WL.Logger.debug("s3s2.html load");
			},
			onUnload : function() {
				WL.Logger.debug("s3s2.html unload");
			}
		});
	}
}

function authLDAP_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	/*	WL.Page.load("pages/HomeScreen.html", {
		onComplete : function() {
			WL.Logger.debug("HomeScreen.html load");
		},
		onUnload : function() {
			WL.Logger.debug("HomeScreen.html unload");
		}
	});	
	WL.SimpleDialog.show("EngadgetReader",
			"Cannot retrieve feed. Please check your internet connectivity.",
			[ {
				text : 'Reload App',
			// handler : WL.Client.reloadApp
			} ]);
*/
	alert('Auth Failed: Try Again');
}

function openNativePage() {
	var params = null;
	WL.NativePage.show('com.EngadgetReader.HelloNative', backFromNativePage,
			params);
}

function backFromNativePage(data) {
	alert("barcode decoded value: " + data.phoneNumber);
	Current_barcode = data.phoneNumber;
	loadFeeds_Scan();
	//document.getElementById('abw_no').value = data.phoneNumber;
	// createNewEntry(data.phoneNumber);
}

function getGPSParams() {

	document.addEventListener("deviceready", onDeviceReady, false);

}

function onDeviceReady() {
 
	//Related to GPS
    navigator.geolocation.getCurrentPosition(onSuccess, onError);
}

function onSuccess(position) {

	document.getElementById('longitude').value = position.coords.longitude;
	document.getElementById('latitude').value = position.coords.latitude;

	// element.innerHTML = 'Latitude: ' + position.coords.latitude + '<br />' +
	//
	// 'Longitude: ' + position.coords.longitude + '<br />' +
	//
	// 'Altitude: ' + position.coords.altitude + '<br />' +
	//
	// 'Accuracy: ' + position.coords.accuracy + '<br />' +
	//
	// 'Altitude Accuracy: ' + position.coords.altitudeAccuracy + '<br />' +
	//
	// 'Heading: ' + position.coords.heading + '<br />' +
	//
	// 'Speed: ' + position.coords.speed + '<br />' +
	//
	// 'Timestamp: ' + position.timestamp + '<br />';

}

// onError Callback receives a PositionError object

//

function onError(error) {

/*	alert('code: ' + error.code + '\n' +

	'message: ' + error.message + '\n');
*/
	document.getElementById('longitude').value = "GPS Failed";
	document.getElementById('latitude').value = "GPS Failed";
	
}

// A button will call this function

function capturePhoto() {

	// Take picture using device camera and retrieve image as base64-encoded
	// string

	navigator.camera.getPicture(onPhotoDataSuccess, onFail, {
		quality : 50,

		destinationType : destinationType.DATA_URL
	});

}



function getGPSParam() {
	WL.Logger.debug("getGPSParam function call *****");
}

function startScan() {
	WL.Logger.debug("startScan function call");
}
function createNewEntry(abwNo) {

	WL.Logger.debug("createNewEntry function call");
	WL.Page.load("pages/newEntry.html", {
		onComplete : function() {
			document.getElementById('abw_no').value = abwNo;
			WL.Logger.debug("createNewEntry.html.html load");
		},
		onUnload : function() {
			WL.Logger.debug("createNewEntry.html.html unload");
		}
	});

}

function create_consignment() {
	WL.Logger.debug("submit function call");

	var dest = document.getElementById('destination').value;
	var sdate = document.getElementById('Date').value;
	
	var sname = document.getElementById('name').value;
	var saddress = document.getElementById('addressline1').value;
	var saddress2 = document.getElementById('addressline2').value;
	var sendercity = document.getElementById('city').value;
	var senderphone = document.getElementById('phonenumber').value;
	var mobnum = document.getElementById('mobilenum').value;
	
	
	var rname = document.getElementById('name2').value;
	var radd1 = document.getElementById('addressline12').value;
	var radd2 = document.getElementById('addressline22').value;
	var rxrcity = document.getElementById('city2').value;
	var rxrphone = document.getElementById('phonenumber2').value;
	var rmobnum = document.getElementById('mobilenum2').value;
	
	var abw_no = Current_barcode;
	
/*	var source = document.getElementById('src').value;
	var raddress = document.getElementById('raddress').value;
	var status = document.getElementById('dropdown').value;*/

	var request1 = {
		"awb_no" : abw_no,
		"destination" : dest,
		"receiverDetails" : {
			"address" : radd1,
			"awb_no" : abw_no,
			"city" : dest,
			"contact" : rxrphone,
			"name" : rname,
			"zip" : "58818"
		},
		"senderDetails" : {
			"address" : saddress,
			"awb_no" : abw_no,
			"city" : sendercity,
			"contact" : senderphone,
			"name" : sname,
			"zip" : "9006"
		},
		"sendingDate" : sdate,
		"source" : sendercity,
		"status" : "New Entry"
	};
	var req2 = JSON.stringify(request1);
	WL.Logger.debug("submit function call request: " + req2);
	createConsignment(req2);
}
function createConsign() {
	WL.Logger.debug("create consignment function call");
	WL.Page.load("pages/newEntry.html", {
		onComplete : function() {
			getGPSParams();
			WL.Logger.debug("newEntry.html load");
		},
		onUnload : function() {
			WL.Logger.debug("newEntry.html unload");
		}
	});

}

function createConsignment(req3) {
	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();
	var invocationData = {
		adapter : 'RSSReader',
		procedure : 'writeConsignmentDetails',
		parameters : [ req3 ]
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : create_loadFeedsSuccess,
		onFailure : create_loadFeedsFailure,
	});
}

function create_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result actual: " + JSON.stringify(result));
	alert("New Entry added into database");

}

function create_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	alert("Submission Failed. Please try Again");
}

back = function() {
	WL.Logger.debug("PAGE1NS::back");
	WL.Page.back();
};

function updateConsign() {
	WL.Logger.debug("s8s2.html buttonClick");
	WL.Page.load("s8s2.html", {
		onComplete : function() {
			onLoaded(result);
			WL.Logger.debug("s8s2.html load");
		},
		onUnload : function() {
			WL.Logger.debug("s8s2.html unload");
		}
	});
	WL.Logger.debug("PAGE1NS::updateConsign");
}

function doSearch() {
	var abw_no = document.getElementById('abw_no').value;
	WL.Logger.debug("PAGE1NS::doSearch buttonClick: " + abw_no);

	getUpdateCompleteDetails(abw_no);

}

function getUpdateCompleteDetails(request) {

	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');

	busyIndicator.show();

	var invocationData = {

		adapter : 'RSSReader',

		procedure : 'getConsignmentCompleteDetails',

		parameters : [ request ]

	};

	WL.Client.invokeProcedure(invocationData, {

		onSuccess : updateDetails_loadFeedsSuccess,

		onFailure : updateDetails_loadFeedsFailure,

	});

}

function updateDetails_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result: " + JSON.stringify(result));

	WL.Page
			.load(
					"pages/updateConsignment.html",
					{
						onComplete : function() {

							var element = document.getElementById('src');
							element.value = result.invocationResult.source;

							var element = document.getElementById('abw_no');
							element.value = result.invocationResult.awb_no;

							var element = document.getElementById('dest');
							element.value = result.invocationResult.destination;

							var element = document.getElementById('loc');

							if (result.invocationResult.trackDetails != undefined)
								element.value = result.invocationResult.trackDetails.currentLocation;
							else
								element.value = result.invocationResult.trackArray[result.invocationResult.trackArray.length - 1].currentLocation;

							var saddress = document.getElementById('saddress');
							saddress.value = result.invocationResult.senderDetails.address;

							var raddress = document.getElementById('raddress');
							raddress.value = result.invocationResult.receiverDetails.address;

							var sname = document.getElementById('sname');
							sname.value = result.invocationResult.senderDetails.name;

							var rname = document.getElementById('rname');
							rname.value = result.invocationResult.receiverDetails.name;

							var status = document.getElementById('status');
							status.value = result.invocationResult.status;

							var sdate = document.getElementById('sdate');
							sdate.value = result.invocationResult.sendingDate;

							WL.Logger.debug("updateConsignment.html load");
						},
						onUnload : function() {
							WL.Logger.debug("updateConsignment.html unload");
						}
					});

}

function updateDetails_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure. Please try again.");
	busyIndicator.hide();
	WL.SimpleDialog.show("EngadgetReader",
			"Cannot retrieve feed. Please check your internet connectivity.",
			[ {
				text : 'Reload App',
			// handler : WL.Client.reloadApp
			} ]);
}

function getConsignment() {
	WL.Logger.debug("PAGE1NS::getConsignment buttonClick");
	loadFeeds();
	WL.Logger.debug("PAGE1NS::getConsignment111");
}

function doUpdate() {
	WL.Logger.debug("update Details for: "
			+ document.getElementById("AWB").value);
/*	var request1 = {
		"awb_no" : document.getElementById("abw_no").value,
		"destination" : "updates2madras",
		"receiverDetails" : {
			"address" : "sdhloffice",
			"awb_no" : "#ABW123456",
			"city" : "updates2madras",
			"contact" : "60078568777",
			"name" : "sramesh",
			"zip" : "58818"
		},
		"senderDetails" : {
			"address" : "sm g road",
			"awb_no" : "#ABW123456",
			"city" : "skolkota",
			"contact" : "739611348",
			"name" : "sumesh",
			"zip" : "9006"
		},
		"sendingDate" : "29/7/2012",
		"source" : "updateskolkota",
		"status" : "Delivered",
		"receivingDate" : "31/7/2012",
		"currentLocation" : "updates2madras"
	};*/ // old request - 21st aug
	
	var requesttemp = {
			"awb_no" : document.getElementById("AWB").value,
			"destination" : document.getElementById('dest').value,
			"receiverDetails" : {
				"address" : document.getElementById('raddress').value,
				"awb_no" : document.getElementById("AWB").value,
				"city" : document.getElementById('dest').value,
				"contact" : "60078568777",
				"name" : document.getElementById('rname').value,
				"zip" : "58818"
			},
			"senderDetails" : {
				"address" : document.getElementById('saddress').value,
				"awb_no" : document.getElementById("AWB").value,
				"city" : document.getElementById('src').value,
				"contact" : "739611348",
				"name" : document.getElementById('sname').value,
				"zip" : "9006"
			},
			"sendingDate" : document.getElementById('sdate').value,
			"source" : document.getElementById('src').value,
			"status" : document.getElementById('deliverystatus').value,
			"receivingDate" : document.getElementById('udate').value,
			"currentLocation" : document.getElementById('dest').value
		};
	
	var request1 = {
			"awb_no" : document.getElementById("AWB").value,
			"receiverDetails" : {
				"awb_no" : document.getElementById("AWB").value
			},
			"senderDetails" : {
				"awb_no" : document.getElementById("AWB").value
			},
			"status" : document.getElementById('deliverystatus').value,
			"receivingDate" : document.getElementById('udate').value
		};
	
	var req2 = JSON.stringify(request1);
	WL.Logger.debug("requset for update: " + req2);
	update_loadFeeds(req2);
}

function loadFeeds() {
	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();
	WL.Logger.debug("Feed retrieve success111");
	var invocationData = {
		adapter : 'RSSReader',
		procedure : 'getConsignmentName',
		parameters : []
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : loadFeedsSuccess,
		onFailure : loadFeedsFailure,
	});
}

function loadFeeds_Scan() {
	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();
	WL.Logger.debug("Feed retrieve success111");
	var invocationData = {
		adapter : 'RSSReader',
		procedure : 'getConsignmentName',
		parameters : []
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : loadFeedsSuccess_Scan,
		onFailure : loadFeedsFailure_Scan,
	});
}

function doOK() {
	alert("Done.");
}
function update_loadFeeds(req3) {
	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();
	var invocationData = {
		adapter : 'RSSReader',
		procedure : 'updateConsignmentDetails',
		parameters : [ req3 ]
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : update_loadFeedsSuccess,
		onFailure : update_loadFeedsFailure,
	});
}

function update_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result: " + JSON.stringify(result));

	alert("update consignment status :" + result.invocationResult.isSuccessful
			+ " statusCode: " + result.invocationResult.statusCode);

}

function update_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	alert("update consignment status :" + result.invocationResult.isSuccessful
			+ " statusCode: " + result.invocationResult.statusCode+"Please try Again");
}

function onLoaded(result) {

	var len = result.invocationResult.consignmentDetails.length;

	if (len == undefined) {
		WL.Logger.debug("result.invocationResult.length undefined****");
		WL.Logger.debug("abwNo[]: "
				+ result.invocationResult.consignmentDetails.awb_no);
		var ul = document.getElementById('list');
		var new_element = document.createElement('li');
		new_element.id = "LI";
		new_element.innerHTML = result.invocationResult.consignmentDetails.awb_no;
		new_element.setAttribute("onclick", "showExample(this.id)");
		ul.appendChild(new_element);
	} else {
		for ( var i = 0; i < result.invocationResult.consignmentDetails.length; i++) {
			WL.Logger.debug("abwNo[" + i + "]: "
					+ result.invocationResult.consignmentDetails[i].awb_no);
			var ul = document.getElementById('list');
			var new_element = document.createElement('li');
			new_element.id = "LI" + i;
			new_element.innerHTML = result.invocationResult.consignmentDetails[i].awb_no;
			new_element.setAttribute("onclick", "showExample(this.id)");
			ul.appendChild(new_element);
		}
	}
}

function showExample(id) {

	WL.Logger.debug("ID: " + id);
	var list_value = document.getElementById(id).innerHTML;
	WL.Logger.debug("show example inside function: " + list_value);

	var request1 = list_value;

	getConsignmentCompleteDetails(request1);

}

function getConsignmentCompleteDetails(request) {

	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');

	busyIndicator.show();

	var invocationData = {

		adapter : 'RSSReader',

		procedure : 'getConsignmentCompleteDetails',

		parameters : [ request ]

	};

	WL.Client.invokeProcedure(invocationData, {

		onSuccess : consDetails_loadFeedsSuccess,

		onFailure : consDetails_loadFeedsFailure,

	});

}

function consDetails_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result: " + JSON.stringify(result));

	WL.Page.load("pages/consignmentDetail.html", {
		onComplete : function() {

			var element = document.getElementById('src');
			element.value = result.invocationResult.source;

			var element = document.getElementById('abw_no');
			element.value = result.invocationResult.awb_no;

			var element = document.getElementById('dest');
			element.value = result.invocationResult.destination;

			var element = document.getElementById('status');
			element.value = result.invocationResult.status;

			var element = document.getElementById('sender');
			element.value = result.invocationResult.senderDetails.name;
			var element = document.getElementById('receiver');
			element.value = result.invocationResult.receiverDetails.name;
			var element = document.getElementById('saddress');
			element.value = result.invocationResult.senderDetails.address;
			var element = document.getElementById('raddress');
			element.value = result.invocationResult.receiverDetails.address;
			var element = document.getElementById('sdate');
			element.value = result.invocationResult.sendingDate;

			WL.Logger.debug("consignmentDetails.html load");
		},
		onUnload : function() {
			WL.Logger.debug("consignmentDetails.html unload");
		}
	});

}

function consDetails_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	WL.SimpleDialog.show("EngadgetReader",
			"Cannot retrieve feed. Please check your internet connectivity.",
			[ {
				text : 'Reload App',
			// handler : WL.Client.reloadApp
			} ]);
}

function loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success: " + JSON.stringify(result));
	busyIndicator.hide();
	WL.Page.load("pages/getConsignment.html", {
		onComplete : function() {
			onLoaded(result);
			WL.Logger.debug("getConsignment.html load: ");
		},
		onUnload : function() {
			WL.Logger.debug("getConsignment.html unload");
		}
	});

	for ( var i = 0; i < result.invocationResult.consignmentDetails.length; i++) {
		WL.Logger.debug("abwNo[" + i + "]: "
				+ result.invocationResult.consignmentDetails[i].awb_no);
		var ul = document.getElementById('list');
		var new_element = document.createElement('li');
		new_element.id = "LI" + i;
		new_element.innerHTML = result.invocationResult.consignmentDetails[i].awb_no;
		ul.appendChild(new_element);
	}

}

function loadFeedsSuccess_Scan(result) {
	WL.Logger.debug("Feed retrieve success: " + JSON.stringify(result));
	busyIndicator.hide();
	WL.Page.load("s4s2.html", {
		onComplete : function() {
			onLoaded(result);
			WL.Logger.debug("s4s2.html load: ");
		},
		onUnload : function() {
			WL.Logger.debug("s4s2.html unload");
		}
	});

	document.getElementById('text1').value = Current_barcode;
	var boolean flag = false;
	for ( var i = 0; i < result.invocationResult.consignmentDetails.length; i++) {
		var barcode_value = result.invocationResult.consignmentDetails[i].awb_no;
		
		if(barcode_value == Current_barcode)
		{
			flag = true;
			WL.Logger.debug("abwNo Found:" + barcode_value);
		}else{
			
			flag = false;
			WL.Logger.debug("abwNo NOT Found - barcode available:"+barcode_value+"barcode scanned:"+Current_barcode);
		}
	}
	if(flag){
		
	}else{
		
	}

}

function loadFeedsFailure_Scan(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	alert("Server down. Scan Again and Retry");
}

function loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	WL.SimpleDialog.show("EngadgetReader",
			"Cannot retrieve feed. Please check your internet connectivity.",
			[ {
				text : 'Reload App',
			} ]);
}

function displayFeeds(items) {
	var ul = $('itemsList');
	for ( var i = 0; i < items.length; i++) {
		var li = new Element('li').update(items[i].title);
		var pubDate = new Element('div', {
			'class' : 'pubDate'
		}).update(items[i].pubDate);

		li.insert(pubDate);

		ul.insert(li);
	}
}

function getConsignmentDetail() {
	alert("getConsignment Detail");
}

function doLogin_DHL() {

	if (busyIndicator == null)
		busyIndicator = new WL.BusyIndicator('AppBody');
	busyIndicator.show();

	var userN = document.getElementById('username').value;
	var pwd = document.getElementById('password').value;
	WL.Logger.debug("userN: "+userN+" pwd: "+pwd);
	
	
	var request = {"password":"password","userID":"user1"};
	var request1 = JSON.stringify(request);
	
	var invocationData = {
		adapter : 'RSSReader',
		procedure : 'doAuthenticateDHL',
		parameters : [ request1 ]
	};

	WL.Client.invokeProcedure(invocationData, {
		onSuccess : authDHL_loadFeedsSuccess,
		onFailure : authDHL_loadFeedsFailure,
	});
}

function authDHL_loadFeedsSuccess(result) {
	WL.Logger.debug("Feed retrieve success");
	busyIndicator.hide();
	WL.Logger.debug("result actual: " + JSON.stringify(result));
	alert("Authentication successful.Please Use LDAP authentication using submit button.");

}

function authDHL_loadFeedsFailure(result) {
	WL.Logger.error("Feed retrieve failure");
	busyIndicator.hide();
	WL.SimpleDialog.show("EngadgetReader",
			"DHL WebServices Authentication Failed.Please try again.",
			[ {
				text : 'Reload App',
			// handler : WL.Client.reloadApp
			} ]);
}

/* JavaScript content from js/DellLogin.js in folder android */

// This method is invoked after loading the main HTML and successful initialization of the Worklight runtime.
function wlEnvInit(){
    wlCommonInit();
    // Environment initialization code goes here
}