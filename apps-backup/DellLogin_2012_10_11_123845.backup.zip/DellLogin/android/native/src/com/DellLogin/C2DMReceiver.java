package com.DellLogin;

public class C2DMReceiver extends com.worklight.androidgap.push.C2DMReceiver {
	//Nothing to do here...
}
