package com.DellLogin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;


public class HelloNative extends Activity {

	EditText editText = null;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//String name = getIntent().getStringExtra("nameParam");
		
		LinearLayout linearLayout = new LinearLayout(this);
		linearLayout.setOrientation(LinearLayout.VERTICAL);
		setContentView(linearLayout);
		
//		TextView textView1 = new TextView(this);
//		textView1.setText("Name received from JavaScript :: " + name);
//		
//		TextView textView2 = new TextView(this);
//		textView2.setText("Enter the phone number");
//		
//		editText = new EditText(this);
//		editText.setText("1234567890");
		
		Button submitButton = new Button(this);
		submitButton.setText("Start");
		submitButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
/*				String phoneNumber = editText.getText().toString();
				Intent phoneNumberInfo = new Intent();
				phoneNumberInfo.putExtra("phoneNumber", phoneNumber);
				setResult(RESULT_OK, phoneNumberInfo);
				finish();
*/				
//		        Intent intent = new Intent(getApplicationContext(),com.google.zxing.client.android.CaptureActivity.class);
		        Intent intent = new Intent("com.google.zxing.client.android.SCAN");
				CharSequence[] modes = new CharSequence[] { "QR_CODE_MODE",
						"PRODUCT_MODE", "ONE_D_MODE", "DATA_MATRIX_MODE" };
				intent.putExtra("SCAN_MODE", modes);		        
//		        intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
		        startActivityForResult(intent, 0);				
			}
		});

//		linearLayout.addView(textView1);
//		linearLayout.addView(textView2);
//		linearLayout.addView(editText);
		linearLayout.addView(submitButton);
	}

	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
	    if (requestCode == 0) {
	        if (resultCode == RESULT_OK) {
	            String contents = intent.getStringExtra("SCAN_RESULT");
	            String format = intent.getStringExtra("SCAN_RESULT_FORMAT");
	           // Intent phoneNumberInfo = new Intent();
	            intent.putExtra("phoneNumber", contents);
				setResult(RESULT_OK, intent);
				finish();
	           // Toast.makeText(this, contents, Toast.LENGTH_LONG).show();
	            // Handle successful scan
	        } else if (resultCode == RESULT_CANCELED) {
	            // Handle cancel
	        	Toast.makeText(this, "FAILED", Toast.LENGTH_LONG).show();
	        	finish();
	        }
	    }
	}	
}
